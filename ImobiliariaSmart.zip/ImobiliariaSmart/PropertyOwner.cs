﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImobiliariaSmart
{
    public class PropertyOwner : PluginImplementation
    {
        public override void ExecutePlugin(IServiceProvider serviceProvider)
        {

            if (Context.InputParameters.Contains("Target") && Context.InputParameters["Target"] is Entity)
            {
                Entity owner = (Entity)this.Context.InputParameters["Target"];

                EntityReference imovel = (EntityReference)owner["smt_name"];
                
                var query_smt_imovel = imovel.Id;

                // Instantiate QueryExpression query
                QueryExpression query = new QueryExpression("smt_negociacao");

                // Add columns to query.ColumnSet
                query.ColumnSet.AddColumns("smt_negociacaoid", "smt_name", "createdon", "smt_proprietario");
                query.AddOrder("smt_name", OrderType.Ascending);

                // Define filter query.Criteria
                query.Criteria.AddCondition("smt_name", ConditionOperator.Equal, query_smt_imovel);
                //query.Criteria.AddCondition("smt_proprietario", ConditionOperator.NotNull);
                EntityCollection proprietario = this.Service.RetrieveMultiple(query);
                

                // Define Condition Values                
                var query_smt_imovelid = imovel.Id;

                // Instantiate QueryExpression query
                QueryExpression query2 = new QueryExpression("smt_imovel");

                // Add columns to query.ColumnSet
                query2.ColumnSet.AddColumns("smt_imovelid", "smt_nomeproprietario");

                // Define filter query.Criteria
                query2.Criteria.AddCondition("smt_imovelid", ConditionOperator.Equal, query_smt_imovelid);
                query2.Criteria.AddCondition("smt_nomeproprietario", ConditionOperator.NotNull);
                EntityCollection nomeProprietario = this.Service.RetrieveMultiple(query2);

                //proprietario["smt_proprietario"] = nomeProprietario["smt_nomeproprietario"];

                //this.Service.Update(proprietario);
            }
        }
    }
}

﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImobiliariaSmart
{
    public class ErrorDate : PluginImplementation
    {
        public override void ExecutePlugin(IServiceProvider serviceProvider)
        {
            Entity owner = (Entity)this.Context.InputParameters["Target"];
            EntityReference imovel = (EntityReference)owner["smt_imovel"];

            var tipo = owner["smt_tiponegociacao"];
            if (tipo.GetHashCode() == 922340000)
            {
                DateTime proprietario = (DateTime)owner["smt_contratode"];
                DateTime proprietarioAte = (DateTime)owner["smt_contratoate"];
                
                var query_smt_contratode = proprietario;
                var query_smt_contratoate = proprietarioAte;
                
                var query = new QueryExpression("smt_negociacao");
                
                query.ColumnSet.AddColumns("smt_negociacaoid", "smt_name", "createdon");
                query.AddOrder("smt_name", OrderType.Ascending);

                
                query.Criteria.AddCondition(imovel.LogicalName, ConditionOperator.NotNull);
                query.Criteria.AddCondition("smt_contratode", ConditionOperator.OnOrAfter, query_smt_contratode);
                query.Criteria.AddCondition("smt_contratoate", ConditionOperator.OnOrBefore, query_smt_contratoate);
                EntityCollection imovelFinal = this.Service.RetrieveMultiple(query);

                if (imovelFinal.Entities.Count() > 0)
                    throw new InvalidPluginExecutionException("Já existe um aluguel com essa data ");

            }
        }
    }
}

﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImobiliariaSmart
{
    public class Amount : PluginImplementation
    {
        public override void ExecutePlugin(IServiceProvider serviceProvider)
        {

            if (Context.MessageName.ToLower() == "create" && Context.PrimaryEntityName == "smt_negociacao")
            {
                if (Context.InputParameters.Contains("Target") && Context.InputParameters["Target"] is Entity)
                {
                    Entity negotiation = (Entity)this.Context.InputParameters["Target"];
                    Entity negotiationPostImage = (Entity)this.Context.PostEntityImages["PostImage"];

                    var tipo = negotiation["smt_tiponegociacao"];
                    if (tipo.GetHashCode() == 922340001)
                    {
                        Money value = (Money)negotiation["smt_valor"];

                        EntityReference corretor = negotiationPostImage.Contains("smt_corretor") ? (EntityReference)negotiationPostImage["smt_corretor"] : null;

                        if (corretor == null)
                            throw new InvalidPluginExecutionException("Não foi encontrada nenhum corretor na post image");

                        Entity corretorTotal = this.Service.Retrieve(corretor.LogicalName, corretor.Id, new ColumnSet("smt_valorarrecadado"));

                        Money corretorTotalValue = corretorTotal.Contains("smt_valorarrecadado") ? (Money)corretorTotal["smt_valorarrecadado"] : new Money() { Value = new decimal(0) };

                        decimal newTotalValue = corretorTotalValue.Value + (value.Value * 8)/ 100;
                        corretorTotal["smt_valorarrecadado"] = new Money(newTotalValue);
                        this.Service.Update(corretorTotal); 
                    }

                    


                }
            }
        }
    }
}

﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImobiliariaSmart
{
    public class NegotiationDate : PluginImplementation
    {
        public override void ExecutePlugin(IServiceProvider serviceProvider)
        {

            if (Context.InputParameters.Contains("Target") && Context.InputParameters["Target"] is Entity)
            {
                Entity owner = (Entity)this.Context.InputParameters["Target"];

                Entity proprietarioPostImage = (Entity)this.Context.PostEntityImages["PostImage"];

                DateTime date = (DateTime)owner["createdon"];
                EntityReference proprietario = proprietarioPostImage.Contains("smt_proprietario") ? (EntityReference)proprietarioPostImage["smt_proprietario"] : null;

                if (proprietario == null)
                    throw new InvalidPluginExecutionException("Não foi encontrada nenhum proprietário na post image");

                Entity corretorTotal = this.Service.Retrieve(proprietario.LogicalName, proprietario.Id, new ColumnSet("smt_dataultimavendaaluguel"));



                corretorTotal["smt_dataultimavendaaluguel"] = date;

                this.Service.Update(corretorTotal);
            }
        }
    }
}


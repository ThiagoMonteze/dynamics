﻿if (typeof (Account) == "undefined") { Account = {} }
if (typeof (Account.Dynamics) == "undefined") { Account.Dynamics = {} }

Account.Dynamics = {
    DNM2_NivelDaConta: {
        Silver: 431820000,
        Gold: 431820001,
        Platinum: 431820002

    },
    DNM2_PorteDaConta: {
        Pequeno: 431820000,
        Medio: 431820001,
        Grande: 431820002

    },
    OnLoad: function (context) {
        this.CNPJOnChange(context);
        this.CEPOnChange(context);
        this.NivelDoClienteOnChange(context);
        this.UpperCaseOnChange(context);
    },

    UpperCaseOnChange: function (context) {
        var formContext = context.getFormContext();
        var form1 = "name";

        if (formContext.getAttribute(form1).getValue() > 0 || formContext.getAttribute(form1).getValue() != null) {
            var form = formContext.getAttribute(form1).getValue();


            form = form.toLowerCase().split(" ");
            for (var i = 0; i < form.length; i++) {
                form[i] = form[i][0].toUpperCase() + form[i].slice(1);
            }

            formContext.getAttribute(form1).setValue(form.join(" "));
        }
        else
            return;
    },
    CNPJOnChange: function (context) {
        var formContext = context.getFormContext();
        var cnpjField = "dnm1_cnpj";

        var cnpj = formContext.getAttribute(cnpjField).getValue();

        if (cnpj == "" || cnpj == null)
            return;

        cnpj = cnpj.replace(".", "").replace(".", "").replace("/", "").replace("-", "");

        if (cnpj.length != 14) {
            formContext.getAttribute(cnpjField).setValue("");
            this.DynamicsCustomAlert("Digite 14 numeros no CNPJ", "Erro de validação");
        }
        else {
            cnpj = cnpj.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1.$2.$3/$4-$5");

            var id = Xrm.Page.data.entity.getId();
            var accountIdQuery = "";

            if (id.length > 0) {
                accountIdQuery = " and accountid ne " + id;
            }

            Xrm.WebApi.online.retrieveMultipleRecords("account", "?$select=dnm1_cnpj&$filter=dnm1_cnpj eq '" + cnpj + "'" + accountIdQuery).then(
                function success(results) {
                    if (results.entities.length > 0) {
                        formContext.getAttribute(cnpjField).setValue("");
                        Account.Dynamics.DynamicsCustomAlert("Já existe uma conta com esse CNPJ", "CNPJ Duplicado!");
                    }
                    else {
                        formContext.getAttribute(cnpjField).setValue(cnpj);
                    }
                },
                function (error) {
                    Account.Dynamics.DynamicsCustomAlert(error.message, "Error");
                }
            );
        }
    },
    CEPOnChange: function (context) {
        var formContext = context.getFormContext();
        var cepField = "address1_postalcode";

        var cep = formContext.getAttribute(cepField).getValue();

        if (cep == "" || cep == null)
            return;

        cep = cep.replace("-", "");

        if (cep.length != 8) {
            formContext.getAttribute(cepField).setValue("");
            this.DynamicsCustomAlert("Digite 8 numeros no CEP", "Erro de validação");
        }
        else {
            cep = cep.replace(/^(\d{5})(\d{3})/, "$1-$2");
            formContext.getAttribute(cepField).setValue(cep);
        }

    },

    NivelDoClienteOnChange: function (context) {
        var formContext = context.getFormContext();
        var attributeName = "dnm1_portecliente";


        var valorCampo = formContext.getAttribute(attributeName).getValue();

        if (valorCampo == Account.Dynamics.DNM2_PorteDaConta.Pequeno) {
            formContext.getAttribute("dnm1_nivelcliente").setValue(Account.Dynamics.DNM2_NivelDaConta.Silver);
        }

        else if (valorCampo == Account.Dynamics.DNM2_PorteDaConta.Medio) {
            formContext.getAttribute("dnm1_nivelcliente").setValue(Account.Dynamics.DNM2_NivelDaConta.Gold);
        }

        else if (valorCampo == Account.Dynamics.DNM2_PorteDaConta.Grande) {
            formContext.getAttribute("dnm1_nivelcliente").setValue(Account.Dynamics.DNM2_NivelDaConta.Platinum);
        }

        else {
            if (valorCampo == null || valorCampo == "") {
                formContext.getAttribute("dnm1_nivelcliente").setValue(null);
            }
        }

    },

    DynamicsCustomAlert: function (alertText, alertTitle) {
        var alertStrings = {
            confirmButtonLabel: "OK",
            text: alertText,
            title: alertTitle
        };

        var alertOptions = {
            height: 120,
            width: 200
        };

        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
    }

}
﻿if (typeof (Opportunity) == "undefined") { Opportunity = {} }
if (typeof (Opportunity.Dynamics) == "undefined") { Opportunity.Dynamics = {} }

Opportunity.Dynamics = {    
    OnLoad: function (context) {
        this.UpperCaseOnChange(context);
        
    },
    UpperCaseOnChange: function (context) {
        var formContext = context.getFormContext();
        var form1 = "name";

        if (formContext.getAttribute(form1).getValue() > 0 || formContext.getAttribute(form1).getValue() != null) {
            var form = formContext.getAttribute(form1).getValue();


            form = form.toLowerCase().split(" ");
            for (var i = 0; i < form.length; i++) {
                form[i] = form[i][0].toUpperCase() + form[i].slice(1);
            }

            formContext.getAttribute(form1).setValue(form.join(" "));
        }
        else
            return;
    },
    NumeroDaOportunidadeOnChange: function (context) {
        let formContext = context.getFormContext();
        let numeroDaOportunidadeField = "dnm1_numerodaoportunidade";

        let numeroDaOportunidade = formContext.getAttribute(numeroDaOportunidadeField).getValue();

        if (numeroDaOportunidade == "" || numeroDaOportunidade == null)
            return;

        numeroDaOportunidade = numeroDaOportunidade.replace("-", "").replace("-", "");


        if (numeroDaOportunidade.length != 9) {
            formContext.getAttribute(numeroDaOportunidadeField).setValue("");
            this.DynamicsCustomAlert("Digite 9 números alfa numéricos no padrão 00000-0A0A", "Erro de validação");
        }
        else {
            numeroDaOportunidade = numeroDaOportunidade.replace(/^(\d{5})(\w{4})/, "OPP-$1-$2");
            numeroDaOportunidade = numeroDaOportunidade.toUpperCase();

            let id = Xrm.Page.data.entity.getId();
            let opportunityIdQuery = "";

            if (id.length > 0) {
                opportunityIdQuery = " and opportunityid ne " + id;
            }

            Xrm.WebApi.online.retrieveMultipleRecords("opportunity", "?$select=dnm1_numerodaoportunidade&$filter=dnm1_numerodaoportunidade eq '" + numeroDaOportunidade + "'" + opportunityIdQuery).then(
                function success(results) {
                    if (results.entities.length > 0) {
                        formContext.getAttribute(numeroDaOportunidadeField).setValue("");
                        Opportunity.Dynamics.DynamicsCustomAlert("Já existe uma conta com esse numero de Oportunidade", "Numero de Oportunidade Duplicado!");
                    }
                    else {
                        formContext.getAttribute(numeroDaOportunidadeField).setValue(numeroDaOportunidade);
                    }
                },
                function (error) {
                    Opportunity.Dynamics.DynamicsCustomAlert(error.message, "Error");
                }
            );
        }
    },
    DynamicsCustomAlert: function (alertText, alertTitle) {
        let alertStrings = {
            confirmButtonLabel: "OK",
            text: alertText,
            title: alertTitle
        };

        let alertOptions = {
            height: 120,
            width: 200
        };

        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
    }
}
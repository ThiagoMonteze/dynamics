﻿if (typeof (Contact) == "undefined") { Contact = {} }
if (typeof (Contact.Dynamics) == "undefined") { Contact.Dynamics = {} }

Contact.Dynamics = {
    CPFOnChange: function (context) {
        var formContext = context.getFormContext();
        var cpfField = "dnm1_cpf";
        if (formContext.getAttribute(cpfField).getValue() > 0 || formContext.getAttribute(cpfField).getValue() != null) {
            var cpf = formContext.getAttribute(cpfField).getValue();


            cpf = cpf.replace(".", "").replace(".", "").replace("-", "");

            if (cpf.length != 11) {
                formContext.getAttribute(cpfField).setValue("");
                this.DynamicsCustomAlert("Digite 11 numeros no CPF", "Erro de validação");
            }
            else {
                cpf = cpf.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");

                var id = Xrm.Page.data.entity.getId();
                var contactIdQuery = "";

                if (id.length > 0) {
                    contactIdQuery = " and contactid ne " + id;
                }

                Xrm.WebApi.online.retrieveMultipleRecords("contact", "?$select=dnm1_cpf&$filter=dnm1_cpf eq '" + cpf + "'" + contactIdQuery).then(
                    function success(results) {
                        if (results.entities.length > 0) {
                            formContext.getAttribute(cpfField).setValue("");
                            Contact.Dynamics.DynamicsCustomAlert("Já existe um contato com esse CPF", "CPF Duplicado!");
                        }
                        else {
                            formContext.getAttribute(cpfField).setValue(cpf);
                        }
                    },
                    function (error) {
                        Contact.Dynamics.DynamicsCustomAlert(error.message, "Error");
                    }
                );
            }
        }
        else {
            return;
        }
    },


    DynamicsCustomAlert: function (alertText, alertTitle) {
        var alertStrings = {
            confirmButtonLabel: "OK",
            text: alertText,
            title: alertTitle
        };

        var alertOptions = {
            height: 120,
            width: 200
        };

        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
    }

}
﻿if (typeof (Opportunity) == "undefined") { Opportunity = {} }
if (typeof (Opportunity.Dynamics) == "undefined") { Opportunity.Dynamics = {} }

Opportunity.Dynamics = {
    Atributos: {
        DNM1_NomeOportunidade: "name",
        DNM1_NumeroOportunidade: "dnm1_numerodaoportunidade",
        DNM1_ContatoOportunidade: "parentcontactid",
        DNM1_ContaOportunidade: "parentaccountid",
        DNM1_PeriodoOportunidade: "purchasetimeframe",
        DNM1_MoedaOportunidade: "transactioncurrencyid",
        DNM1_OrcamentoOportunidade: "budgetamount",
        DNM1_ProcessoCompraOportunidade: "purchaseprocess",
        DNM1_descricaoOportunidade: "description",
        DNM1_CategoriaPrevisaoOportunidade: "msdyn_forecastcategory",
        DNM1_IntegracaoOportunidade: "dnm1_integracao",
        DNM1_SituacaoAtualOportunidade: "currentsituation",
        DNM1_NecessidadeClienteOportunidade: "customerneed",
        DNM1_SolucaoPropostaOportunidade: "proposedsolution",
        DNM1_ListaPrecosOportunidade: "pricelevelid",
        DNM1_DescontoPorcentagemOportunidade: "discountpercentage",
        DNM1_DescontoOportunidade: "discountamount",
        DNM1_ValorFreteOportunidade: "freightamount"
    },
    OnLoad: function (context) {              
        let formContext = context.getFormContext();
        let integration = "dnm1_integracao";        

        if (formContext.getAttribute(integration).getValue() == true)
        {
            
            formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_NomeOportunidade).setDisabled(true);
            formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_NumeroOportunidade).setDisabled(true);
            formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_ContaOportunidade).setDisabled(true);
            formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_ContatoOportunidade).setDisabled(true);
            formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_PeriodoOportunidade).setDisabled(true);
            formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_MoedaOportunidade).setDisabled(true);
            formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_OrcamentoOportunidade).setDisabled(true);
            formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_ProcessoCompraOportunidade).setDisabled(true);
            formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_descricaoOportunidade).setDisabled(true);
            formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_CategoriaPrevisaoOportunidade).setDisabled(true);
            formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_IntegracaoOportunidade).setDisabled(true);
            formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_SituacaoAtualOportunidade).setDisabled(true);
            formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_NecessidadeClienteOportunidade).setDisabled(true);
            formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_SolucaoPropostaOportunidade).setDisabled(true);
            //formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_ListaPrecosOportunidade).setDisabled(true);
            //formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_DescontoPorcentagemOportunidade).setDisabled(true);
            //formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_DescontoOportunidade).setDisabled(true);
            //formContext.getControl(Opportunity.Dynamics.Atributos.DNM1_ValorFreteOportunidade).setDisabled(true);

        }
    },
    NumeroDaOportunidadeOnChange: function (context) {
        let formContext = context.getFormContext();
        let numeroDaOportunidadeField = "dnm1_numerodaoportunidade";

        let numeroDaOportunidade = formContext.getAttribute(numeroDaOportunidadeField).getValue();

        if (numeroDaOportunidade == "" || numeroDaOportunidade == null)
            return;

        numeroDaOportunidade = numeroDaOportunidade.replace("-", "").replace("-", "");


        if (numeroDaOportunidade.length != 9) {
            formContext.getAttribute(numeroDaOportunidadeField).setValue("");
            this.DynamicsCustomAlert("Digite 9 números alfa numéricos no padrão 00000-0A0A", "Erro de validação");
        }
        else {
            numeroDaOportunidade = numeroDaOportunidade.replace(/^(\d{5})(\w{4})/, "OPP-$1-$2");
            numeroDaOportunidade = numeroDaOportunidade.toUpperCase();

            let id = Xrm.Page.data.entity.getId();
            let opportunityIdQuery = "";

            if (id.length > 0) {
                opportunityIdQuery = " and opportunityid ne " + id;
            }

            Xrm.WebApi.online.retrieveMultipleRecords("opportunity", "?$select=dnm1_numerodaoportunidade&$filter=dnm1_numerodaoportunidade eq '" + numeroDaOportunidade + "'" + opportunityIdQuery).then(
                function success(results) {
                    if (results.entities.length > 0) {
                        formContext.getAttribute(numeroDaOportunidadeField).setValue("");
                        Opportunity.Dynamics.DynamicsCustomAlert("Já existe uma conta com esse numero de Oportunidade", "Numero de Oportunidade Duplicado!");
                    }
                    else {
                        formContext.getAttribute(numeroDaOportunidadeField).setValue(numeroDaOportunidade);
                    }
                },
                function (error) {
                    Opportunity.Dynamics.DynamicsCustomAlert(error.message, "Error");
                }
            );
        }
    },
    DynamicsCustomAlert: function (alertText, alertTitle) {
        let alertStrings = {
            confirmButtonLabel: "OK",
            text: alertText,
            title: alertTitle
        };

        let alertOptions = {
            height: 120,
            width: 200
        };

        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
    }
}
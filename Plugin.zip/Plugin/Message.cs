﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin
{
    public class Message : PluginImplementation
    {
        public string TableName = "dnm2_notificacaoaocliente";

        public override void ExecutePlugin(IServiceProvider serviceProvider)
        {
            //Entity clientOpportunity = (Entity)Context.InputParameters["Target"];
            //if (clientOpportunity.Contains("parentaccountid"))
            //{
            //Guid clientOpportunityMessage = ((EntityReference)clientOpportunity["parentaccountid"]).Id;
            //Entity account = Service.Retrieve("account", clientOpportunityMessage, new ColumnSet("parentaccountid"));

            //if (Context.MessageName == "Create")
            //{
            Entity message = new Entity(this.TableName);            
            message["dnm2_datadanotificacao"] = new DateTime(2021, 10, 27);
            message["dnm2_mensagem"] = "Obrigado e tal!";
            Guid productId = Service.Create(message);
            //}
            //}
        }
    }
}

﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin
{
    public class Message : PluginImplementation
    {
        public string TableName = "dnm2_notificacaoaocliente";

        public override void ExecutePlugin(IServiceProvider serviceProvider)
        {
            Entity clientOpportunity = (Entity)Context.InputParameters["Target"];

            //if (clientOpportunity.Contains("parentaccountid"))                
            //{
            //Guid clientOpportunityMessage = ((EntityReference)clientOpportunity["parentaccountid"]).Id;

            //Entity account = this.Service.Retrieve("opportunity", clientOpportunityMessage, new ColumnSet("parentaccountid"));

            //Guid accountOpportunity = account.Contains("parentaccountid") ? (Guid)account["parentaccountid"] : default; 

            if (Context.MessageName == "Create")
            {
                Entity message = new Entity(this.TableName);
                message["dnm2_nomedocliente"] = new Guid("24d8db07-8a37-ec11-8c64-00224837df99");
                message["dnm2_datadanotificacao"] = new DateTime(2021, 10, 27);
                message["dnm2_mensagem"] = "Obrigado e tal!";
                Service.Create(message);
            }

        }
    }
}


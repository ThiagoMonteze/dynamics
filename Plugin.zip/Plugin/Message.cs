﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin
{
    public class Message : PluginImplementation
    {
        public string TableName = "dnm2_notificacaoaocliente";

        public override void ExecutePlugin(IServiceProvider serviceProvider)
        {
            Entity clientOpportunity = (Entity)Context.InputParameters["Target"];

            //if (clientOpportunity.Contains("parentaccountid"))                
            //{
            Guid clientOpportunityMessage = ((EntityReference)clientOpportunity["parentaccountid"]).Id;
            
            //throw new InvalidPluginExecutionException(clientOpportunityMessage + "Erro");

            //Entity account = Service.Retrieve("account", clientOpportunityMessage, new ColumnSet("parentaccountid"));

            //Guid accountOpportunity = account.Contains("parentaccountid") ? (Guid)account["parentaccountid"] : default; 

            if (Context.MessageName == "Update")
            {
                Entity message = new Entity(this.TableName);
                message["dnm2_nomedocliente"] = new EntityReference("parentaccountid", clientOpportunityMessage);
                message["dnm2_datadanotificacao"] = DateTime.Now;
                message["dnm2_mensagem"] = "Obrigado!";
                Service.Create(message);
            }

        }
    }
}


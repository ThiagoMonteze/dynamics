﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plugin
{
    public class ProductIntegration : PluginImplementation
    {
        public override void ExecutePlugin(IServiceProvider serviceProvider)
        {

            if (Context.MessageName == "Create" && Context.Mode == Convert.ToInt32(MeuEnum.Mode.Synchronous) &&
               Context.Stage == Convert.ToInt32(MeuEnum.Stage.PostOperation))
            {


                TracingService.Trace("Inicio Plugin");
                Entity entidadeContexto = null;

                if (Context.InputParameters.Contains("Target"))
                    entidadeContexto = (Entity)Context.InputParameters["Target"];

                if (entidadeContexto.LogicalName == "product")
                {
                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                               <entity name='product'>
                                 <attribute name='name' />
                                  <attribute name='productid' />
                                     <attribute name='productnumber' />
                                     <attribute name='description' />
                                          <attribute name='statecode' />
                                      <attribute name='productstructure' />
                                      <attribute name='parentproductid' />
                                 <order attribute='productnumber' descending='false' />
                                 </entity>
                                    </fetch>";

                    var Retorno = Service.RetrieveMultiple(new FetchExpression(fetch));

                    if (Retorno.Entities.Count > 0)
                    {
                        throw new InvalidPluginExecutionException("Produto existente.");
                    }
                }
            }
        }

       
    }
}

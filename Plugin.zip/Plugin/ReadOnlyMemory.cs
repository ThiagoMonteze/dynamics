﻿namespace Plugin
{
    internal class ReadOnlyMemory
    {
    }
}
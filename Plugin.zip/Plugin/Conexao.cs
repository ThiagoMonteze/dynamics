﻿using System;

namespace Plugin
{
    internal class Conexao
    {
        internal object Origem()
        {
            throw new NotImplementedException();
        }

        internal object Destino()
        {
            throw new NotImplementedException();
        }
    }
}
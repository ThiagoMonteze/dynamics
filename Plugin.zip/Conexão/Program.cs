﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conexão
{
    class Program
    {
        static void Main(string[] args)
        {

            Conexao conexaoOrigem = new Conexao();
            var serviceproxyOrigem = conexaoOrigem.ObterOrigem();


            Conexao conexaoDestino = new Conexao();
            var serviceproxyDestino = conexaoDestino.ObterDestino();

            //chamar metodos para execucao

            //ImportarContato(serviceproxyDestino);
            //ImportarConta(serviceproxyDestino);
            //ImportarClientePotencial(serviceproxyDestino);
            //ImportarPedidos(serviceproxyDestino);
            //ImportarItensPedidos(serviceproxyDestino);

            Console.WriteLine("FIM DA IMPORTAÇÃO!");
            Console.ReadKey();


        }
    }

    internal class Conexao
    {
    }
}

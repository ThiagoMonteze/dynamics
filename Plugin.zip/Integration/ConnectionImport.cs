﻿using System;
using System.Net;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Tooling.Connector;

namespace DebuggerSolution
{
    class ConnectionImport
    {
        private static CrmServiceClient crmServiceClientDestino;
        private static CrmServiceClient crmServiceClientOrigem;
        public CrmServiceClient ObterOrigem()
        {
            var connectionStringCRM =
               "AuthType=OAuth;" +
               "Username=tcc_FYI@grupo1dynamics.onmicrosoft.com;" +
               "Password=Grupo1@FYI;" +
               "Url=https://org706822bb.crm2.dynamics.com;" +
               "AppId=7fa3f8de-ebc9-46a3-b910-56e9b12bc8c2;" +
               "RedirectUri=app://58145B91-0C36-4500-8554-080854F2AC97;";

            if (crmServiceClientDestino == null)
            {
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                crmServiceClientDestino = new CrmServiceClient(connectionStringCRM);
            }
            return crmServiceClientDestino;
        }

        public CrmServiceClient ObterDestino()
        {
            var connectionStringCRM =
               "AuthType=OAuth;" +
               "Username=grupo1@dynamics2G1.onmicrosoft.com;" +
               "Password=@dynamics2G1;" +
               "Url=https://org5eb90507.crm2.dynamics.com;" +
               "AppId=47a5208a-7f24-4862-b227-4149ed7eb05a;" +
               "RedirectUri=app://58145B91-0C36-4500-8554-080854F2AC97;";

            if (crmServiceClientOrigem == null)
            {
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                crmServiceClientOrigem = new CrmServiceClient(connectionStringCRM);
            }
            return crmServiceClientOrigem;
        }
    }
}

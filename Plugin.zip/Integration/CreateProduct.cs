﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integration
{
    public class CreateProduct
    {
        public string TableName = "dnm2_notificacaoaocliente";

        public void Product(IOrganizationService service)
        {
            Entity message = new Entity(this.TableName);           
            message["dnm2_mensagem"] = "Ogrigado!";
            Guid productId = service.Create(message);
        }
    }
}

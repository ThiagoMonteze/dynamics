﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integration
{
    public class CreateProduct
    {
        public string TableName = "account";

        public IOrganizationService Service { get; set; }

        public CreateProduct(IOrganizationService service)
        {
            this.Service = service;
        }

        public void Product()
        {
            this.Service.Delete(this.TableName, new Guid("d0a19cdd-88df-e311-b8e5-6c3be5a8b200"));
        }
    }
}

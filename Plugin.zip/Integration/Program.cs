﻿using DebuggerSolution;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integration
{
    class Program
    {
        static void Main(string[] args)
        {
            //IOrganizationService service = ConnectionFactory.Destino();

            //CreateProduct product = new CreateProduct(service);
            //product.Product();

            //inicio
            ConnectionImport conexaoOrigem = new ConnectionImport();
            var serviceproxyOrigem = conexaoOrigem.ObterOrigem();

            ConnectionImport conexaoDestino = new ConnectionImport();
            var serviceproxyDestino = conexaoDestino.ObterDestino();

            Console.WriteLine("Aperte Enter para começar o Import");
            Console.ReadLine();
            ImportarConta(serviceproxyDestino);
            ImportarContato(serviceproxyDestino);
            ImportarFatura(serviceproxyDestino);
            ImportarConcorrentes(serviceproxyDestino);
            ImportarLinhaDeFatura(serviceproxyDestino);
            Console.WriteLine("Concluído!");
        }

        #region Import Dynamics

        #region Importar Conta        
        static void ImportarConta(CrmServiceClient serviceproxyDestino)
        {
            QueryExpression queryExpression = new QueryExpression("account");
            queryExpression.Criteria.AddCondition("dnm1_cnpj", ConditionOperator.NotNull);
            queryExpression.ColumnSet = new ColumnSet("name", "dnm1_nivelcliente", "dnm1_portecliente", "dnm1_cnpj");

            ConnectionImport conexaoOrigem = new ConnectionImport();
            var serviceproxyOrigem = conexaoOrigem.ObterOrigem();
            EntityCollection colecaoEntidadesOrigem = serviceproxyOrigem.RetrieveMultiple(queryExpression);

            foreach (var item in colecaoEntidadesOrigem.Entities)
            {
                var entidade = new Entity("account");
                Guid registro = item.Id;

                if (item.Attributes.Contains("accountid"))
                entidade.Attributes.Add("accountid", registro);
                entidade.Attributes.Add("name", item["name"]);
                entidade.Attributes.Add("dnm1_nivelcliente", item["dnm1_nivelcliente"]);
                entidade.Attributes.Add("dnm1_portecliente", item["dnm1_portecliente"]);
                entidade.Attributes.Add("dnm1_cnpj", item["dnm1_cnpj"]);
                //entidade.Attributes.Add("address1_postalcode", item["address1_postalcode"]);

                serviceproxyDestino.Create(entidade);

            }

        }
        #endregion

        #region Importar Contato
        static void ImportarContato(CrmServiceClient serviceproxyDestino)
        {
            QueryExpression queryExpression = new QueryExpression("contact");
            queryExpression.Criteria.AddCondition("firstname", ConditionOperator.NotNull);
            queryExpression.Criteria.AddCondition("dnm1_cpf", ConditionOperator.NotNull);
            queryExpression.ColumnSet = new ColumnSet("firstname", "lastname", "dnm1_cpf");

            ConnectionImport conexaoOrigem = new ConnectionImport();
            var serviceproxyOrigem = conexaoOrigem.ObterOrigem();
            EntityCollection colecaoEntidadesOrigem = serviceproxyOrigem.RetrieveMultiple(queryExpression);

            foreach (var item in colecaoEntidadesOrigem.Entities)
            {
                var entidade = new Entity("contact");
                Guid registro = item.Id;

                if (item.Attributes.Contains("contactid"))
                entidade.Attributes.Add("contactid", registro);
                entidade.Attributes.Add("firstname", item["firstname"]);
                entidade.Attributes.Add("lastname", item["lastname"]);
                //entidade.Attributes.Add("dnm1_cpf", item["dnm1_cpf"]);

                serviceproxyDestino.Create(entidade);

            }

        }
        #endregion

        #region Importar Concorrentes        
        static void ImportarConcorrentes(CrmServiceClient serviceproxyDestino)
        {
            QueryExpression queryExpression = new QueryExpression("competitor");
            queryExpression.Criteria.AddCondition("competitorid", ConditionOperator.NotNull);            
            queryExpression.ColumnSet = new ColumnSet("name","websiteurl");

            ConnectionImport conexaoOrigem = new ConnectionImport();
            var serviceproxyOrigem = conexaoOrigem.ObterOrigem();
            EntityCollection colecaoEntidadesOrigem = serviceproxyOrigem.RetrieveMultiple(queryExpression);

            foreach (var item in colecaoEntidadesOrigem.Entities)
            {
                var entidade = new Entity("competitor");
                Guid registro = item.Id;

                if (item.Attributes.Contains("competitorid"))
                entidade.Attributes.Add("competitorid", registro);
                entidade.Attributes.Add("name", item["name"]);
                //entidade.Attributes.Add("websiteurl", item["websiteurl"]);                

                serviceproxyDestino.Create(entidade);

            }

        }
        #endregion

        #region Importar Fatura        
        static void ImportarFatura(CrmServiceClient serviceproxyDestino)
        {
            QueryExpression queryExpression = new QueryExpression("invoice");
            queryExpression.Criteria.AddCondition("invoicenumber", ConditionOperator.NotNull);
            queryExpression.ColumnSet = new ColumnSet("invoicenumber", "name", "pricelevelid", "salesorderid", "customerid", "totallineitemamount");

            ConnectionImport conexaoOrigem = new ConnectionImport();
            var serviceproxyOrigem = conexaoOrigem.ObterOrigem();
            EntityCollection colecaoEntidadesOrigem = serviceproxyOrigem.RetrieveMultiple(queryExpression);

            foreach (var item in colecaoEntidadesOrigem.Entities)
            {
                var entidade = new Entity("invoice");
                Guid registro = item.Id;

                if (item.Attributes.Contains("invoiceid"))
                entidade.Attributes.Add("invoiceid", registro);
                entidade.Attributes.Add("invoicenumber", item["invoicenumber"]);
                entidade.Attributes.Add("pricelevelid", item["pricelevelid"]);
                entidade.Attributes.Add("name", item["name"]);
                //entidade.Attributes.Add("salesorderid", item["salesorderid"]);
                entidade.Attributes.Add("customerid", item["customerid"]);
                entidade.Attributes.Add("totallineitemamount", item["totallineitemamount"]);

                registro = serviceproxyDestino.Create(entidade);

            }

        }
        #endregion

        #region Importar Linha de Fatura        
        static void ImportarLinhaDeFatura(CrmServiceClient serviceproxyDestino)
        {
            QueryExpression queryExpression = new QueryExpression("invoicedetail");
            queryExpression.Criteria.AddCondition("invoicedetailid", ConditionOperator.NotNull);
            queryExpression.ColumnSet = new ColumnSet("invoiceid", "productname", "priceperunit", "uomid", "quantity", "manualdiscountamount", "extendedamount");

            ConnectionImport conexaoOrigem = new ConnectionImport();
            var serviceproxyOrigem = conexaoOrigem.ObterOrigem();
            EntityCollection colecaoEntidadesOrigem = serviceproxyOrigem.RetrieveMultiple(queryExpression);

            foreach (var item in colecaoEntidadesOrigem.Entities)
            {
                var entidade = new Entity("invoicedetail");
                Guid registro = item.Id;

                if (item.Attributes.Contains("invoicedetailid"))
                entidade.Attributes.Add("invoicedetailid", registro);                
                entidade.Attributes.Add("productname", item["productname"]);                
                entidade.Attributes.Add("priceperunit", item["priceperunit"]);
                entidade.Attributes.Add("invoiceid", item["invoiceid"]);
                entidade.Attributes.Add("quantity", item["quantity"]);
                //entidade.Attributes.Add("manualdiscountamount", item["manualdiscountamount"]);
                entidade.Attributes.Add("extendedamount", item["extendedamount"]);


                serviceproxyDestino.Create(entidade);

            }

        }
        #endregion

        #endregion End Import

    }
}

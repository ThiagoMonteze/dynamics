﻿using DebuggerSolution;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integration
{
    class Program
    {
        static void Main(string[] args)
        {
            //IOrganizationService service = ConnectionFactory.Destino();

            //CreateProduct product = new CreateProduct(service);
            //product.Product();

            //inicio
            ConnectionImport conexaoOrigem = new ConnectionImport();
            var serviceproxyOrigem = conexaoOrigem.ObterOrigem();

            ConnectionImport conexaoDestino = new ConnectionImport();
            var serviceproxyDestino = conexaoDestino.ObterDestino();
                        
            //ImportarConta(serviceproxyDestino);
            //ImportarContato(serviceproxyDestino);
            //ImportarFatura(serviceproxyDestino);
            //ImportarConcorrentes(serviceproxyDestino);
            ImportarLinhaDeFatura(serviceproxyDestino);
        }

        #region ROBO

        #region Importar Conta        
        static void ImportarConta(CrmServiceClient serviceproxyDestino)
        {
            QueryExpression queryExpression = new QueryExpression("account");
            queryExpression.Criteria.AddCondition("dnm1_cnpj", ConditionOperator.NotNull);
            queryExpression.ColumnSet = new ColumnSet("name", "dnm1_nivelcliente", "dnm1_portecliente", "dnm1_cnpj");

            ConnectionImport conexaoOrigem = new ConnectionImport();
            var serviceproxyOrigem = conexaoOrigem.ObterOrigem();
            EntityCollection colecaoEntidadesOrigem = serviceproxyOrigem.RetrieveMultiple(queryExpression);

            foreach (var item in colecaoEntidadesOrigem.Entities)
            {
                var entidade = new Entity("account");
                Guid registro = item.Id;

                if (item.Attributes.Contains("accountid"))
                entidade.Attributes.Add("accountid", registro);
                entidade.Attributes.Add("name", item["name"]);
                entidade.Attributes.Add("dnm1_nivelcliente", item["dnm1_nivelcliente"]);
                entidade.Attributes.Add("dnm1_portecliente", item["dnm1_portecliente"]);
                entidade.Attributes.Add("dnm1_cnpj", item["dnm1_cnpj"]);
                //entidade.Attributes.Add("address1_postalcode", item["address1_postalcode"]);

                serviceproxyDestino.Create(entidade);

            }

        }
        #endregion

        #region Importar Contato
        static void ImportarContato(CrmServiceClient serviceproxyDestino)
        {
            QueryExpression queryExpression = new QueryExpression("contact");
            queryExpression.Criteria.AddCondition("firstname", ConditionOperator.NotNull);
            queryExpression.Criteria.AddCondition("lastname", ConditionOperator.NotNull);
            queryExpression.ColumnSet = new ColumnSet("firstname", "lastname", "dnm1_cpf");

            ConnectionImport conexaoOrigem = new ConnectionImport();
            var serviceproxyOrigem = conexaoOrigem.ObterOrigem();
            EntityCollection colecaoEntidadesOrigem = serviceproxyOrigem.RetrieveMultiple(queryExpression);

            foreach (var item in colecaoEntidadesOrigem.Entities)
            {
                var entidade = new Entity("contact");
                Guid registro = item.Id;

                if (item.Attributes.Contains("contactid"))
                entidade.Attributes.Add("contactid", registro);
                entidade.Attributes.Add("firstname", item["firstname"]);
                entidade.Attributes.Add("lastname", item["lastname"]);
                //entidade.Attributes.Add("dnm1_cpf", item["dnm1_cpf"]);

                serviceproxyDestino.Create(entidade);

            }

        }
        #endregion

        #region Importar Concorrentes        
        static void ImportarConcorrentes(CrmServiceClient serviceproxyDestino)
        {
            QueryExpression queryExpression = new QueryExpression("competitor");
            queryExpression.Criteria.AddCondition("competitorid", ConditionOperator.NotNull);            
            queryExpression.ColumnSet = new ColumnSet("name","websiteurl");

            ConnectionImport conexaoOrigem = new ConnectionImport();
            var serviceproxyOrigem = conexaoOrigem.ObterOrigem();
            EntityCollection colecaoEntidadesOrigem = serviceproxyOrigem.RetrieveMultiple(queryExpression);

            foreach (var item in colecaoEntidadesOrigem.Entities)
            {
                var entidade = new Entity("competitor");
                Guid registro = item.Id;

                if (item.Attributes.Contains("competitorid"))
                entidade.Attributes.Add("competitorid", registro);
                entidade.Attributes.Add("name", item["name"]);
                //entidade.Attributes.Add("websiteurl", item["websiteurl"]);                

                serviceproxyDestino.Create(entidade);

            }

        }
        #endregion

        #region Importar Fatura        
        static void ImportarFatura(CrmServiceClient serviceproxyDestino)
        {
            QueryExpression queryExpression = new QueryExpression("invoice");
            queryExpression.Criteria.AddCondition("invoicenumber", ConditionOperator.NotNull);
            queryExpression.ColumnSet = new ColumnSet("name", "pricelevelid", "opportunityid", "salesorderid", "customerid", "totallineitemamount");

            ConnectionImport conexaoOrigem = new ConnectionImport();
            var serviceproxyOrigem = conexaoOrigem.ObterOrigem();
            EntityCollection colecaoEntidadesOrigem = serviceproxyOrigem.RetrieveMultiple(queryExpression);

            foreach (var item in colecaoEntidadesOrigem.Entities)
            {
                var entidade = new Entity("invoice");
                Guid registro = item.Id;

                if (item.Attributes.Contains("invoiceid"))
                entidade.Attributes.Add("invoice", registro);
                entidade.Attributes.Add("invoicenumber", item["invoicenumber"]);
                entidade.Attributes.Add("pricelevelid", item["pricelevelid"]);
                entidade.Attributes.Add("opportunityid", item["opportunityid"]);
                entidade.Attributes.Add("salesorderid", item["salesorderid"]);
                entidade.Attributes.Add("customerid", item["customerid"]);
                entidade.Attributes.Add("totallineitemamount", item["totallineitemamount"]);

                registro = serviceproxyDestino.Create(entidade);

            }

        }
        #endregion

        #region Importar Linha de Fatura        
        static void ImportarLinhaDeFatura(CrmServiceClient serviceproxyDestino)
        {
            QueryExpression queryExpression = new QueryExpression("productpricelevel");
            queryExpression.Criteria.AddCondition("pricelevelid", ConditionOperator.Equal, new Guid("8876d516-af3a-ec11-8c62-00224837c031"));
            queryExpression.ColumnSet = new ColumnSet("pricelevelid", "productid", "uomid", "amount");

            ConnectionImport conexaoOrigem = new ConnectionImport();
            var serviceproxyOrigem = conexaoOrigem.ObterOrigem();
            EntityCollection colecaoEntidadesOrigem = serviceproxyOrigem.RetrieveMultiple(queryExpression);

            foreach (var item in colecaoEntidadesOrigem.Entities)
            {
                var entidade = new Entity("productpricelevel");
                Guid registro = item.Id;

                if (item.Attributes.Contains("pricelevelid"))
                entidade.Attributes.Add("pricelevelid", registro);                
                entidade.Attributes.Add("productid", item["productid"]);
                //entidade["uomscheduleid"] = new EntityReference("uomschedule", new Guid("8f39143b-5a38-ec11-8c64-0022483784c6"));
                entidade.Attributes.Add("uomid", item["uomid"]);
                entidade.Attributes.Add("amount", item["amount"]);
                //entidade.Attributes.Add("defaultuomscheduleid", item["defaultuomscheduleid"]);
                //entidade.Attributes.Add("defaultuomid", item["defaultuomid"]);
                //entidade.Attributes.Add("baseuom", item["baseuom"]);


                serviceproxyDestino.Create(entidade);

            }

        }
        #endregion

        #endregion ROBO

    }
}
